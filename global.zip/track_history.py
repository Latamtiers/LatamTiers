#!/usr/bin/env python3
"""
track_history.py — Tracking de tiers para PVPHQ (fuente: Lunaris, con DoH fallback).

Comandos:
    python track_history.py                     # Corrida única
    python track_history.py --check             # Diagnóstico de conexión
    python track_history.py --watch             # Auto-update cada 5 min
    python track_history.py --watch -i 60       # Auto-update cada 60 seg
    python track_history.py --inject            # Genera ranking_export.json
    python track_history.py --reset             # Borra el historial
    python track_history.py --source ./file.json  # JSON local en vez de Lunaris
    python track_history.py --print             # Imprime el JSON crudo
"""

from __future__ import annotations

import argparse
import json
import signal
import socket
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ============================================================
# CONFIG
# ============================================================
LUNARIS_HOST = "mx.lunarishost.com"
LUNARIS_PORT = 20037
LUNARIS_PATH = "/web"
LUNARIS_URL = f"http://{LUNARIS_HOST}:{LUNARIS_PORT}{LUNARIS_PATH}"
DEFAULT_INTERVAL = 300

TIER_SCORE = {
    "HT1": 60, "MT1": 45, "LT1": 30,
    "HT2": 30, "MT2": 20, "LT2": 10,
    "HT3": 10, "MT3": 6,  "LT3": 4,
    "HT4": 4,  "MT4": 3,  "LT4": 2,
    "HT5": 2,  "MT5": 1,  "LT5": 1,
}

TIERS_LOW_TO_HIGH = [
    "LT5", "MT5", "HT5", "LT4", "MT4", "HT4",
    "LT3", "MT3", "HT3", "LT2", "MT2", "HT2",
    "LT1", "MT1", "HT1",
]

MODE_ALIASES = {
    "SWORD": "sword",
    "AXE": "axe",
    "MACE": "mace",
    "POT": "pot",
    "NETHPOT": "nethpot",
    "NETHERITE_POT": "nethpot",
    "NETHER_POT": "nethpot",
    "UHC": "uhc",
    "SHIELDLESS_UHC": "uhc",
    "SMP": "smp",
    "CRYSTAL": "crystal",
    "DIAMOND_SMP": "crystal",
    "DIASMP": "crystal",
}
VALID_MODES = set(MODE_ALIASES.values())

_STOP = False


# ============================================================
# DNS
# ============================================================
def resolve_system(hostname: str) -> str | None:
    try:
        infos = socket.getaddrinfo(hostname, None, socket.AF_INET)
        return infos[0][4][0] if infos else None
    except socket.gaierror:
        return None


def resolve_doh(hostname: str, timeout: int = 6) -> str | None:
    endpoints = [
        f"https://cloudflare-dns.com/dns-query?name={hostname}&type=A",
        f"https://dns.google/resolve?name={hostname}&type=A",
    ]
    for url in endpoints:
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/dns-json"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            for ans in data.get("Answer", []) or []:
                if ans.get("type") == 1 and ans.get("data"):
                    return ans["data"]
        except Exception:
            continue
    return None


def resolve_host(hostname: str) -> tuple[str | None, str]:
    ip = resolve_system(hostname)
    if ip:
        return ip, "system"
    ip = resolve_doh(hostname)
    if ip:
        return ip, "doh"
    return None, "none"


# ============================================================
# UTIL
# ============================================================
def now_ms() -> int:
    return int(time.time() * 1000)


def iso_to_ms(s: str | None) -> int | None:
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)
    except Exception:
        return None


def fmt_date(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d %H:%M:%S")


def normalize_mode(raw_key: str) -> str | None:
    key = raw_key.strip().upper()
    mode = MODE_ALIASES.get(key, raw_key.strip().lower())
    return mode if mode in VALID_MODES else None


def atomic_write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def log(quiet: bool, msg: str) -> None:
    if not quiet:
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] {msg}")


# ============================================================
# FETCH con DoH fallback
# ============================================================
def fetch_ranking(source: str | None = None, timeout: int = 20) -> dict[str, Any] | None:
    if source:
        p = Path(source).resolve()
        if not p.exists():
            print(f"❌ No existe {p}", file=sys.stderr)
            return None
        try:
            with p.open("r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            print(f"❌ {p} no es JSON válido: {e}", file=sys.stderr)
            return None

    ip, how = resolve_host(LUNARIS_HOST)
    if ip is None:
        print(f"❌ No se pudo resolver {LUNARIS_HOST}", file=sys.stderr)
        print(f"   Ni por DNS del sistema ni por DoH.", file=sys.stderr)
        return None

    # Intento 1: hostname
    url = LUNARIS_URL
    headers = {"Accept": "application/json", "User-Agent": "PVPHQ-tracker/2.0"}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
        return json.loads(body)
    except (socket.gaierror, urllib.error.URLError):
        pass
    except json.JSONDecodeError as e:
        print(f"❌ Lunaris no devolvió JSON válido: {e}", file=sys.stderr)
        return None
    except urllib.error.HTTPError as e:
        print(f"❌ Lunaris HTTP {e.code}: {e.reason}", file=sys.stderr)
        return None

    # Intento 2: IP directa
    url_ip = f"http://{ip}:{LUNARIS_PORT}{LUNARIS_PATH}"
    headers_ip = dict(headers)
    headers_ip["Host"] = f"{LUNARIS_HOST}:{LUNARIS_PORT}"
    try:
        req = urllib.request.Request(url_ip, headers=headers_ip)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
        return json.loads(body)
    except urllib.error.HTTPError as e:
        print(f"❌ Lunaris (IP) HTTP {e.code}: {e.reason}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"❌ No se pudo conectar a {ip}:{LUNARIS_PORT} — {e.reason}", file=sys.stderr)
        return None
    except json.JSONDecodeError as e:
        print(f"❌ Lunaris no devolvió JSON válido: {e}", file=sys.stderr)
        return None


# ============================================================
# CHECK — diagnóstico
# ============================================================
def cmd_check(source: str | None) -> int:
    print("=" * 56)
    print("🔍 Diagnóstico de conexión")
    print("=" * 56)

    if source:
        print(f"   Fuente: archivo local → {source}")
        data = fetch_ranking(source)
        if data is None:
            return 1
        print(f"   ✅ JSON válido — {len(data)} jugadores")
        return 0

    print(f"   Host: {LUNARIS_HOST}")
    print(f"   Puerto: {LUNARIS_PORT}")
    print(f"   Path: {LUNARIS_PATH}")
    print()

    print("1) DNS del sistema (IPv4)…")
    ip_sys = resolve_system(LUNARIS_HOST)
    if ip_sys:
        print(f"   ✅ {ip_sys}")
    else:
        print(f"   ❌ Falló")

    print("\n2) DNS over HTTPS (Cloudflare)…")
    ip_doh = resolve_doh(LUNARIS_HOST)
    if ip_doh:
        print(f"   ✅ {ip_doh}")
    else:
        print(f"   ❌ Falló")

    print("\n3) Conexión HTTP…")
    data = fetch_ranking(None)
    if data is None:
        print("   ❌ No se pudo descargar el JSON")
        print()
        print("💡 Posibles causas:")
        print("   - El host está caído (verifica en el navegador)")
        print("   - Tu firewall/VPN bloquea el puerto 20037")
        print("   - El servidor solo acepta desde tu navegador (User-Agent)")
        print()
        print("💡 Alternativa: descarga el JSON desde el navegador, guárdalo")
        print("   como 'ranking.json' en esta carpeta y corre:")
        print("     python track_history.py --source ./ranking.json")
        return 1

    print(f"   ✅ OK — {len(data)} jugadores")
    print()
    print("=" * 56)
    print("🎉 Todo listo. Corre:")
    print("     python track_history.py --watch")
    print("=" * 56)
    return 0


# ============================================================
# EXTRACCIÓN
# ============================================================
def extract_player_modes(player: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    tiers = player.get("tiers") or player.get("modalidades") or {}
    for raw_key, val in tiers.items():
        if not isinstance(val, dict):
            continue
        mode = normalize_mode(raw_key)
        if mode is None:
            continue
        tier = val.get("tier")
        if not isinstance(tier, str) or tier not in TIER_SCORE:
            continue
        at = iso_to_ms(val.get("obtained_at")) or val.get("updatedAt") or now_ms()
        result[mode] = {"tier": tier, "at": at}
    return result


def compute_direction(prev: str | None, curr: str) -> str:
    if prev is None:
        return "up"
    if prev not in TIERS_LOW_TO_HIGH or curr not in TIERS_LOW_TO_HIGH:
        return "same"
    pi, ci = TIERS_LOW_TO_HIGH.index(prev), TIERS_LOW_TO_HIGH.index(curr)
    return "up" if ci > pi else "down" if ci < pi else "same"


# ============================================================
# TRACKING
# ============================================================
def track_all(ranking, history, *, dry_run=False):
    cambios = []
    for uuid, player in ranking.items():
        if not isinstance(player, dict):
            continue
        nick = player.get("nick", "?")
        region = player.get("region")
        modes = extract_player_modes(player)

        if uuid not in history:
            history[uuid] = {"nick": nick, "modes": {}}
        history[uuid]["nick"] = nick
        if region:
            history[uuid]["region"] = region
        hmodes = history[uuid].setdefault("modes", {})

        for mode, info in modes.items():
            current_tier = info["tier"]
            current_at = info["at"]
            entries = hmodes.get(mode, [])

            if not entries:
                hmodes[mode] = [{"tier": current_tier, "at": current_at}]
                cambios.append({
                    "uuid": uuid, "nick": nick, "mode": mode,
                    "from": None, "to": current_tier,
                    "direction": "up", "at": current_at, "seeded": True,
                })
                continue

            last = entries[-1]
            prev_tier = last.get("tier")
            if prev_tier != current_tier:
                use_at = current_at if current_at > last.get("at", 0) else now_ms()
                entries.append({"tier": current_tier, "at": use_at})
                cambios.append({
                    "uuid": uuid, "nick": nick, "mode": mode,
                    "from": prev_tier, "to": current_tier,
                    "direction": compute_direction(prev_tier, current_tier),
                    "at": use_at, "seeded": False,
                })

    if not dry_run:
        history["__meta__"] = {
            "lastUpdate": now_ms(),
            "lastUpdateHuman": fmt_date(now_ms()),
            "source": LUNARIS_URL,
            "version": 3,
        }
    return history, cambios


def inject_into_ranking(ranking, history):
    for uuid, player in ranking.items():
        if not isinstance(player, dict):
            continue
        hnode = history.get(uuid, {})
        hmodes = hnode.get("modes", {}) if isinstance(hnode, dict) else {}
        tiers = player.get("tiers") or player.get("modalidades")
        if not isinstance(tiers, dict):
            continue
        for raw_key, val in tiers.items():
            if not isinstance(val, dict):
                continue
            mode = normalize_mode(raw_key)
            if mode is None:
                continue
            entries = hmodes.get(mode)
            if not entries:
                continue
            val["history"] = [{"tier": e["tier"], "at": e["at"]} for e in entries]
            val["updatedAt"] = entries[-1]["at"]
    return ranking


def print_stats(history):
    players = [k for k in history.keys() if not k.startswith("__")]
    total_events = total_modes = changes_up = changes_down = 0
    for uuid in players:
        hnode = history[uuid]
        if not isinstance(hnode, dict):
            continue
        for entries in (hnode.get("modes") or {}).values():
            total_modes += 1
            total_events += len(entries)
            for i in range(1, len(entries)):
                d = compute_direction(entries[i - 1]["tier"], entries[i]["tier"])
                if d == "up": changes_up += 1
                elif d == "down": changes_down += 1
    meta = history.get("__meta__", {})
    print("📊 Estadísticas")
    print("─" * 44)
    print(f"  Jugadores rastreados : {len(players)}")
    print(f"  Modos totales        : {total_modes}")
    print(f"  Eventos totales      : {total_events}")
    print(f"  Subidas de tier      : {changes_up}")
    print(f"  Bajadas de tier      : {changes_down}")
    if meta.get("lastUpdateHuman"):
        print(f"  Última actualización : {meta['lastUpdateHuman']}")
    print("─" * 44)


def run_once(args, history_path):
    log(args.quiet, f"📡 Descargando de {args.source or LUNARIS_URL}")
    ranking = fetch_ranking(args.source)
    if ranking is None:
        return 1
    log(args.quiet, f"   → {len(ranking)} jugadores")

    if args.reset and history_path.exists():
        log(args.quiet, f"🧹 --reset: borrando {history_path}")
        if not args.dry_run:
            history_path.unlink()
        history = {}
    elif history_path.exists():
        try:
            with history_path.open("r", encoding="utf-8") as f:
                history = json.load(f)
        except json.JSONDecodeError:
            print(f"⚠️  {history_path} corrupto, se recreará", file=sys.stderr)
            history = {}
    else:
        log(args.quiet, "🌱 Primera ejecución — creando historial")
        history = {}

    new_history, cambios = track_all(ranking, history, dry_run=args.dry_run)
    seeded = [c for c in cambios if c.get("seeded")]
    real = [c for c in cambios if not c.get("seeded")]

    if seeded:
        log(args.quiet, f"🌱 {len(seeded)} modos nuevos")
    if real:
        log(args.quiet, f"✨ {len(real)} cambio(s) detectado(s):")
        for c in real[:30]:
            arrow = "↑" if c["direction"] == "up" else "↓" if c["direction"] == "down" else "="
            frm = c["from"] or "UNRANKED"
            print(f"   {arrow} {c['nick']:20s} {c['mode']:8s}  {frm:8s} → {c['to']}")
        if len(real) > 30:
            print(f"   ...y {len(real) - 30} más")
    elif not seeded:
        log(args.quiet, "💤 Sin cambios")

    if args.dry_run:
        log(args.quiet, "🔍 --dry-run: no se escribió nada")
        return 0

    atomic_write_json(history_path, new_history)
    log(args.quiet, f"💾 Historial guardado en {history_path}")

    if args.inject:
        export_path = history_path.parent / "ranking_export.json"
        atomic_write_json(export_path, inject_into_ranking(ranking, new_history))
        log(args.quiet, f"📝 Export: {export_path}")

    return 0


def _handle_sigint(signum, frame):
    global _STOP
    _STOP = True
    print("\n⏹️  Ctrl+C — deteniendo…")


def run_watch(args, history_path):
    global _STOP
    _STOP = False
    signal.signal(signal.SIGINT, _handle_sigint)
    try:
        signal.signal(signal.SIGTERM, _handle_sigint)
    except (AttributeError, ValueError):
        pass

    interval = args.interval
    print("=" * 56)
    print(f"🔁 Modo watch — cada {interval}s")
    print(f"   Fuente     : {args.source or LUNARIS_URL}")
    print(f"   Historial  : {history_path}")
    print("   Ctrl+C para parar")
    print("=" * 56)

    cycle = 0
    while not _STOP:
        cycle += 1
        print(f"\n── Ciclo #{cycle} ─────────────────────────────────")
        try:
            run_once(args, history_path)
        except Exception as e:
            print(f"⚠️  Error en el ciclo: {e}", file=sys.stderr)
        if _STOP:
            break
        remaining = interval
        while remaining > 0 and not _STOP:
            time.sleep(min(1, remaining))
            remaining -= 1
    print("\n👋 Watch detenido.")
    return 0


def parse_args():
    p = argparse.ArgumentParser(description="Tracking de tiers para PVPHQ (Lunaris).")
    p.add_argument("--history", default="history.json")
    p.add_argument("--source", default=None)
    p.add_argument("--inject", action="store_true")
    p.add_argument("--reset", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--stats", action="store_true")
    p.add_argument("--check", action="store_true",
                   help="Diagnóstico de conexión a Lunaris")
    p.add_argument("--print", dest="print_source", action="store_true")
    p.add_argument("--watch", action="store_true")
    p.add_argument("-i", "--interval", type=int, default=DEFAULT_INTERVAL)
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    history_path = Path(args.history).resolve()

    if args.check:
        return cmd_check(args.source)

    if args.stats:
        if not history_path.exists():
            print(f"❌ No existe {history_path}", file=sys.stderr)
            return 1
        with history_path.open("r", encoding="utf-8") as f:
            print_stats(json.load(f))
        return 0

    if args.print_source:
        ranking = fetch_ranking(args.source)
        if ranking is None:
            return 1
        print(json.dumps(ranking, ensure_ascii=False, indent=2))
        return 0

    if args.watch:
        if args.interval < 5:
            print("⚠️  Intervalo mínimo: 5s", file=sys.stderr)
            args.interval = 5
        return run_watch(args, history_path)

    return run_once(args, history_path)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n⏹️  Interrumpido", file=sys.stderr)
        sys.exit(130)